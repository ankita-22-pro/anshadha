package com.app.core;

public enum Department {
	RND, HR, MARKETING, FINANCE, SALES
}
