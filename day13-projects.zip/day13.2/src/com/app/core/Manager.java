package com.app.core;

public class Manager extends Emp{

}
