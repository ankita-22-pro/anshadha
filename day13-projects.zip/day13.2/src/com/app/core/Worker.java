package com.app.core;

public class Worker extends Emp {

}
