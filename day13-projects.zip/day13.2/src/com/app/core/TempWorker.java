package com.app.core;

public class TempWorker extends Worker {

}
