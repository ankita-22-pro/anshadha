package com.app.core;

public class HRManager extends Manager{

}
